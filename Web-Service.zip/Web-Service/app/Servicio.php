<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class servicio extends Model
{
    Protected $fillable=[
        'nombre','descripcion','foto'
    ];
}
